﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.Intrinsics.X86;

namespace TypesInCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            MainMenu m = new MainMenu();
            m.StartMainMenu();
        }
    }
}

